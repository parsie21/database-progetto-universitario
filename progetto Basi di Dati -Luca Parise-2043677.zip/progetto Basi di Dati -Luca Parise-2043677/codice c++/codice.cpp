#include <cstdio>
#include <iostream>
#include <fstream>
#include <iomanip>
#include "dependencies\include\libpq-fe.h"

using namespace std;

#define PG_HOST     "127.0.0.1"         //oppure "localhost" o "postgresql"
#define PG_USER     "postgres"          //il nostro nome utente
#define PG_DB       "nypd"              //il nome del database
#define PG_PASS     "Paul_A23"          //la vostra password
#define PG_PORT     5432            

void checkResults (PGresult* res, const PGconn* conn) {
    if(PQresultStatus(res) != PGRES_TUPLES_OK)  {
        cout << "Risultati inconsistenti!" << PQerrorMessage(conn) << endl;
        PQclear(res);
        exit(1);
    }
}





int main() {
    char conninfo[250];
    sprintf(conninfo, "user=%s password=%s dbname=%s hostaddr=%s port=%d", PG_USER, PG_PASS, PG_DB, PG_HOST, PG_PORT);

    PGconn * conn = PQconnectdb(conninfo);

    if(PQstatus(conn) != CONNECTION_OK) {
        cout << "Errore di connessione " << PQerrorMessage (conn);
        PQfinish(conn);
        exit(1);
    }
    else {
        cout << "Connessione avvenuta correttamente" << "\n\n\n";

        int n;
        int tuple; 
        int campi; 
        PGresult *res;

        while(n!=-1){
            cout << "scegli la query che vuoi tra le sequenti: " << "\n\n\n";
            cout << "1      restituisci tutte le persone coinvolte nel caso n.500 insieme ai rispettivi ruoli " << endl;
            cout << "2      dammi tutte le persone che hanno gli occhi di colore verde e sono italiane, presenti nel database" << endl;
            cout << "3      dammi i codici, i cognomi e i nomi delle persone che hanno una doppia cittadinanza" << endl;  
            cout << "4      dimmi quante persone nel database vivono ad Harlem " << endl;
            cout << "5      Quanti casi sono stati registrati fino ad oggi per ogni quartiere nel distretto del Bronx ?" << endl;
            cout << "6      elenca i codici delle persone di etnia greca che vivono a brooklyn heights" << endl;
            cout << "7      elenca i codici dei casi di omicidio" << endl;
            cout << "-1     per uscire"  << endl;

            cin >> n; 
            
        
        cout << endl;

        switch(n) {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////             
            
            //restituisci tutte le persone coinvolte nel caso n.500 insieme ai rispettivi ruoli 
            
            case 1:
                res = PQexec(conn, "SELECT codice_caso, data_apertura, data_chiusura, cognome, nome, ruolo FROM casi, persona pers, coinvolgimento coin WHERE pers.codice_persona = coin.cod_persona AND casi.codice_caso = coin.cod_caso AND casi.codice_caso = 500");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;


            PQclear(res);
            cout << endl << endl << endl;
            break;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//dammi tutte le persone che hanno gli occhi di colore verde e sono italiane, presenti nel database

            case 2:
                res = PQexec(conn, "DROP VIEW IF EXISTS italiani; CREATE VIEW italiani AS (	SELECT * FROM persona,cittadinanza	WHERE persona.codice_persona = cittadinanza.cod_persona AND cod_paese='ITA' ); SELECT codice_persona, cognome, nome, nome_paese as provenienza, colore_occhi FROM italiani, dettagli_persona, paesi WHERE italiani.codice_persona = dettagli_persona.cod_persona AND italiani.cod_paese=paesi.codice_paese AND colore_occhi = 'Verde'");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

            PQclear(res);
            cout << endl << endl << endl;
            break;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//dammi i codici, i cognomi e i nomi delle persone che hanno una doppia cittadinanza

            case 3:
                res = PQexec(conn, "SELECT DISTINCT COUNT(*), codice_persona, cognome, nome FROM persona, cittadinanza WHERE cittadinanza.cod_persona=persona.codice_persona GROUP BY codice_persona HAVING COUNT(*)=2 ORDER BY codice_persona DESC");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;
            PQclear(res);
            cout << endl << endl << endl;
            break;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//dimmi quante persone nel database vivono ad Harlem 

            case 4:
                res = PQexec(conn, "SELECT COUNT(*) as residenti_ad_harlem FROM quartiere, residenza WHERE quartiere.codice_quartiere=residenza.cod_quartiere AND nome_quartiere='Harlem'");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;
            PQclear(res);
            cout << endl << endl << endl;
            break;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Quanti casi sono stati registrati fino ad oggi per ogni quartiere nel distretto del Bronx ?

            case 5:
                res = PQexec(conn, "DROP VIEW IF EXISTS quartieri_del_bronx; CREATE VIEW quartieri_del_bronx AS ( 	SELECT codice_quartiere, nome_quartiere	FROM quartiere, luogo, distretto	WHERE quartiere.codice_quartiere=luogo.cod_quartiere AND distretto.codice_distretto = luogo.cod_distretto	AND nome_distretto = 'Bronx'); SELECT COUNT(*) AS n_casi, nome_quartiere FROM scena_del_crimine, quartieri_del_bronx WHERE scena_del_crimine.cod_quartiere = quartieri_del_bronx.codice_quartiere GROUP BY nome_quartiere");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;
            PQclear(res);
            cout << endl << endl << endl;
            break;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//elenca i codici delle persone di etnia greca che vivono a brooklyn heights
            case 6:
                res = PQexec(conn, "SELECT residenti_di_BH.cod_persona, nome_etnia FROM appartenenza, etnia, (	SELECT cod_persona FROM residenza WHERE residenza.cod_quartiere = ( SELECT codice_quartiere FROM quartiere WHERE nome_quartiere = 'Brooklyn Heights') )as residenti_di_BH WHERE residenti_di_BH.cod_persona = appartenenza.cod_persona AND appartenenza.cod_etnia=etnia.codice_etnia AND nome_etnia = 'Greca'");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;
            PQclear(res);
            cout << endl << endl << endl;
            break;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            case 7: 

res = PQexec(conn, "SELECT codice_caso, nome_reato FROM casi, crimine, reato WHERE casi.codice_caso=crimine.cod_caso AND crimine.cod_reato=reato.codice_reato AND nome_reato='Omicidio'");
                checkResults(res, conn);

                tuple = PQntuples(res);
                campi = PQnfields(res);

                for (int i=0; i<campi; ++i) {
                    cout <<left <<setw(32) << PQfname(res,i)  ;
                }
                cout << endl ;
                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;

                for(int i = 0; i<tuple; ++i){
                for(int j=0; j<campi; ++j) {
                    cout << left <<setw(32) << PQgetvalue(res, i, j);
                }
                cout << endl;
            }

                for(int i=0; i<campi; ++i) {
                    cout << setw(32) << "---------------------------";
                }
                cout <<endl;
            PQclear(res);
            cout << endl << endl << endl;





            break;





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case -1: 
            cout << "grazie e arrivederci" << endl;
            break;

            default: cout << "Errore di inserimento numero query; ";
        }
        }



        PQfinish(conn);
    }


    return 0;
}



// per compilare 
// g++ codice.cpp -Ldependencies/lib -lpq -o codice

/*
g++ --version
g++ (GCC) 11.2.0
Copyright (C) 2021 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/*
POSTGRES 15
*/

