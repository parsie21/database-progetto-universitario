il file nypd.sql è quello creato da me e funziona, almeno lo ha sempre fatto, e contiene anch'esso le query come dei commenti alla fine del file.
Basta semplicemente creare il database e dare in pasto ad una query il file. 


il file nypd_backup.sql è quello creato usando postgres e seguendo il procedimento descritto sul file regolamento del progetto presente su stem.
Visto l'indecisione su quale dei due inserire, li ho messi entrambi.